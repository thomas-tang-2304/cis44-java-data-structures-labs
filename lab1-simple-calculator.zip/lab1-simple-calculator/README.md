# lab1-simple-calculator
* Java lab1 product - Calculator Simulator


_To run the file in vscode:_
1. cd to this root folder of this file
2. Type "javac <ilename.java (create filename.class)
3. Type "java filename.java"

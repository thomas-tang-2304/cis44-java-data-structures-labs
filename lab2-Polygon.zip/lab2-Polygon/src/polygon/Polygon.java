package polygon;



public interface Polygon {

    double perimeter();
    double area();
}

// You'll need a Position interface
public interface Position<E> { E getElement();

Position<E> after(); }